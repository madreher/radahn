# C SHARP

This code allows to execute a subset of nodes of LiteGraph directly in Unity.

Still a work in progress.
