YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "ContextMenu",
        "LGraph",
        "LGraphCanvas",
        "LGraphNode",
        "LiteGraph"
    ],
    "modules": [],
    "allModules": [],
    "elements": []
} };
});